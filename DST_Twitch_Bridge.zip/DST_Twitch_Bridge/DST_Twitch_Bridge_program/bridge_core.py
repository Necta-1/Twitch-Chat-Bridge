"""Ядро моста Twitch <-> Don't Starve Together (без интерфейса).

Все тексты для пользователя передаются наружу как ключи переводов (см. i18n.py):
    log(key, **params)                 - строка журнала
    on_status(state, key, **params)    - статус для окна
Перевод ключей в текст выполняет окно программы, поэтому язык можно менять на лету.
"""
import os
import queue
import random
import re
import socket
import ssl
import threading
import time

IN_FILE = "twitch_to_game.txt"
OUT_FILE = "game_to_twitch.txt"
HOST, PORT = "irc.chat.twitch.tv", 6697

CTRL = re.compile(r"[\x00-\x1f\x7f]")
MSG_RE = re.compile(
    r"^(?:@(\S+) )?:([^!\s]+)![^@\s]+@[^.\s]+\.tmi\.twitch\.tv PRIVMSG #(\S+) :(.*)$"
)


class BridgeError(Exception):
    """Ошибка запуска: key - ключ перевода, kw - его параметры."""

    def __init__(self, key, **kw):
        super().__init__(key)
        self.key = key
        self.kw = kw


def clean(text, limit):
    text = CTRL.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > limit:
        text = text[: limit - 3].rstrip() + "..."
    return text


class Inbox:
    """Сообщения Twitch -> игра (файл twitch_to_game.txt)."""

    def __init__(self, dirs, log):
        self.dirs = [d for d in dirs if d]
        self.log = log
        self.lines = []
        self.seq = 0
        self.lock = threading.Lock()

    def add(self, user, text):
        with self.lock:
            self.seq = max(self.seq + 1, int(time.time() * 1000))
            self.lines.append(f"{self.seq}\t{user}\t{text}")
            self.lines = self.lines[-20:]
            data = "\n".join(self.lines) + "\n"
        for d in self.dirs:
            try:
                os.makedirs(d, exist_ok=True)
                tmp = os.path.join(d, IN_FILE + ".tmp")
                with open(tmp, "w", encoding="utf-8", newline="\n") as f:
                    f.write(data)
                os.replace(tmp, os.path.join(d, IN_FILE))
            except OSError as e:
                self.log("log_write_fail", dir=d, err=str(e))


class Bridge:
    """
    settings:
      channel, bot_username, oauth_token,
      master_save_dir, caves_save_dir,
      ignore_users (список), ignore_commands (bool), max_len (int)
    log и on_status вызываются из фоновых потоков.
    state: connecting | connected | error | stopped
    tr(key, **params) нужен только для тестового сообщения и текста ошибки пути.
    """

    def __init__(self, settings, log, on_status=None, tr=None):
        self.s = settings
        self.log = log
        self.on_status = on_status or (lambda state, key, **kw: None)
        self.tr = tr or (lambda key, **kw: key)
        self.stop_event = threading.Event()
        self.send_queue = queue.Queue()
        self.inbox = None
        self.channel = ""
        self.threads = []
        self._auth_failed = False
        self.ignore_users = set()
        self.ignore_commands = True
        self.max_len = 140

    # ------------------------------------------------------------------ запуск
    def start(self):
        s = self.s
        self.channel = (s.get("channel") or "").strip().lstrip("#").lower()
        if not self.channel:
            raise BridgeError("err_no_channel")

        master = s.get("master_save_dir") or ""
        if not master or not os.path.isdir(master):
            raise BridgeError("err_no_world", path=master or self.tr("not_selected"))

        self.ignore_users = {
            u.strip().lower() for u in (s.get("ignore_users") or []) if u.strip()
        }
        self.ignore_commands = bool(s.get("ignore_commands", True))
        try:
            self.max_len = max(20, min(int(s.get("max_len", 140)), 400))
        except (TypeError, ValueError):
            self.max_len = 140

        self.inbox = Inbox([master, s.get("caves_save_dir") or ""], self.log)
        self.stop_event.clear()
        self._auth_failed = False
        self.threads = [
            threading.Thread(target=self._irc_loop, daemon=True),
            threading.Thread(target=self._outbox_loop, daemon=True),
        ]
        for t in self.threads:
            t.start()
        self.log("log_started", channel=self.channel)

    def stop(self):
        self.stop_event.set()
        for t in self.threads:
            t.join(timeout=3)
        self.threads = []
        self.on_status("stopped", "status_stopped")
        self.log("log_stopped")

    def send_test(self):
        if self.inbox is not None:
            self.inbox.add(self.tr("test_sender"), self.tr("test_message"))
            self.log("log_test_sent")

    # ------------------------------------------------------------------ Twitch
    def _irc_loop(self):
        delay = 2
        while not self.stop_event.is_set():
            started = time.time()
            try:
                self._session()
            except Exception as e:
                if self.stop_event.is_set():
                    break
                self.log("log_conn_lost", err=str(e))
                self.on_status("error", "status_reconnecting")
            if time.time() - started > 60:
                delay = 2
            if self.stop_event.wait(delay):
                break
            delay = min(delay * 2, 60)

    def _session(self):
        s = self.s
        token = (s.get("oauth_token") or "").strip()
        nick = (s.get("bot_username") or "").strip().lower()
        authed = bool(token and nick) and not self._auth_failed
        if authed:
            if not token.startswith("oauth:"):
                token = "oauth:" + token
        else:
            nick = f"justinfan{random.randint(10000, 99999)}"
            token = "SCHMOOPIIE"

        self.on_status("connecting", "status_connecting")
        raw = socket.create_connection((HOST, PORT), timeout=30)
        sock = ssl.create_default_context().wrap_socket(raw, server_hostname=HOST)
        sock.settimeout(0.5)
        try:
            def send(line):
                sock.sendall((line + "\r\n").encode("utf-8"))

            send("CAP REQ :twitch.tv/tags twitch.tv/commands")
            send(f"PASS {token}")
            send(f"NICK {nick}")
            send(f"JOIN #{self.channel}")

            buf = b""
            last_send = 0.0
            while not self.stop_event.is_set():
                try:
                    chunk = sock.recv(4096)
                    if not chunk:
                        raise ConnectionError("connection closed by server")
                    buf += chunk
                except socket.timeout:
                    pass

                while b"\r\n" in buf:
                    line, buf = buf.split(b"\r\n", 1)
                    self._handle(line.decode("utf-8", "replace"), send, nick, authed)

                if not authed:
                    self._drain_queue()
                elif time.time() - last_send >= 1.6:
                    try:
                        ts, msg = self.send_queue.get_nowait()
                    except queue.Empty:
                        pass
                    else:
                        if time.time() - ts <= 30:  # устаревшие не отправляем
                            send(f"PRIVMSG #{self.channel} :{msg}")
                            last_send = time.time()
                            self.log("log_g2t", msg=msg)
        finally:
            try:
                sock.close()
            except OSError:
                pass

    def _drain_queue(self):
        while True:
            try:
                self.send_queue.get_nowait()
            except queue.Empty:
                return

    def _handle(self, line, send, nick, authed):
        if line.startswith("PING"):
            send("PONG" + line[4:])
            return

        low = line.lower()
        if "authentication failed" in low or "improperly formatted auth" in low:
            self._auth_failed = True
            self.log("log_auth_failed")
            self.on_status("error", "status_auth_failed")
            raise ConnectionError("authentication failed")

        if " 366 " in line:
            suffix = "rw" if authed else "ro"
            self.log("log_joined_" + suffix, channel=self.channel)
            self.on_status("connected", "status_connected_" + suffix, channel=self.channel)
            return

        if " NOTICE " in line:
            note = line.split(" NOTICE ", 1)[1]
            text_part = note.split(" :", 1)[1] if " :" in note else note
            msg_id = ""
            if line.startswith("@"):
                for tag in line[1:].split(" ", 1)[0].split(";"):
                    if tag.startswith("msg-id="):
                        msg_id = tag[7:]
            self.log("log_notice", msg_id=msg_id, text=text_part)
            return

        m = MSG_RE.match(line)
        if not m:
            return
        tags_raw, login, _chan, text = m.groups()
        tags = dict(t.split("=", 1) for t in (tags_raw or "").split(";") if "=" in t)
        name = tags.get("display-name") or login
        if text.startswith("\x01ACTION ") and text.endswith("\x01"):
            text = text[8:-1]
        self._on_twitch_message(name, login, text)

    def _on_twitch_message(self, name, login, text):
        if login.lower() in self.ignore_users:
            return
        if self.ignore_commands and text.startswith("!"):
            return
        if text.startswith("[DST] "):
            return  # сообщения из игры, которые мост сам отправил в Twitch
        text = clean(text, self.max_len)
        name = clean(name, 25)
        if not text:
            return
        self.log("log_t2g", name=name, text=text)
        self.inbox.add(name, text)

    # ------------------------------------------------------------ игра -> Twitch
    def _outbox_loop(self):
        path = os.path.join(self.s["master_save_dir"], OUT_FILE)
        last = None
        while not self.stop_event.wait(0.5):
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    data = f.read()
            except FileNotFoundError:
                if last is None:
                    last = 0
                continue
            except OSError:
                continue

            if not data.endswith("\n"):
                continue  # файл ещё дописывается

            msgs = []
            for line in data.split("\n"):
                parts = line.split("\t", 2)
                if len(parts) != 3:
                    continue
                try:
                    seq = int(float(parts[0]))
                except ValueError:
                    continue
                msgs.append((seq, parts[1], parts[2]))
            msgs.sort()

            if last is None:
                last = msgs[-1][0] if msgs else 0  # старую историю пропускаем
                continue

            for seq, name, text in msgs:
                if seq > last:
                    last = seq
                    text = clean(text, 400)
                    name = clean(name, 40)
                    if text:
                        self.send_queue.put((time.time(), f"[DST] {name}: {text}"))
