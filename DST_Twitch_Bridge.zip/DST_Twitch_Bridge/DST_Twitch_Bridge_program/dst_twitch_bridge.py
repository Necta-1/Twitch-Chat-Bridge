#!/usr/bin/env python3
"""
DST Twitch Bridge: окно настройки и запуск моста
между чатом Twitch и игровым чатом Don't Starve Together.

Интерфейс переведён на несколько языков (см. i18n.py), язык выбирается в окне.
"""
import configparser
import json
import os
import queue
import time
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from bridge_core import Bridge, BridgeError
from i18n import LANGUAGES, detect_language, get_language, language_from_name, set_language, t

APP_TITLE = "DST Twitch Bridge"
TOKEN_URL = "https://twitchtokengenerator.com"

# Ссылки на поддержку автора (названия сервисов не переводятся).
# Чтобы добавить Patreon, добавьте строку вида:
#   ("Patreon", "https://www.patreon.com/...."),
SUPPORT_LINKS = [
    ("YouTube", "https://www.youtube.com/@Necta_"),
    ("Donatello", "https://donatello.to/necta"),
    ("Ko-fi", "https://ko-fi.com/necta_"),
]

DEFAULTS = {
    "language": "",  # пусто = язык системы
    "channel": "",
    "bot_username": "",
    "oauth_token": "",
    "cluster_dir": "",
    "also_caves": False,
    "ignore_users": "nightbot, streamelements, streamlabs, moobot",
    "ignore_commands": True,
    "max_len": 140,
}

STATUS_COLORS = {
    "connected": "#2e7d32",
    "error": "#c62828",
    "connecting": "#ef6c00",
    "stopped": "#616161",
}


def tx(key, **params):
    """Перевод с подстановками; при ошибке показывает сам ключ, а не падает."""
    try:
        return t(key, **params)
    except (KeyError, IndexError, ValueError):
        return key


# ---------------------------------------------------------------- настройки
def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(base, "DST_Twitch_Bridge")
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, "settings.json")


def load_settings():
    data = dict(DEFAULTS)
    try:
        with open(settings_path(), encoding="utf-8") as f:
            data.update(json.load(f))
    except (OSError, ValueError):
        pass
    return data


def save_settings(data):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ------------------------------------------------------------ поиск миров DST
def klei_roots():
    docs = []
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(260)
        ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf)  # Documents
        docs.append(buf.value)
    except Exception:
        pass
    home = os.path.expanduser("~")
    for sub in ("Documents", os.path.join("OneDrive", "Documents"),
                os.path.join("OneDrive", "Документы"), "Документы"):
        docs.append(os.path.join(home, sub))

    roots = []
    for d in docs:
        root = os.path.join(d, "Klei", "DoNotStarveTogether")
        if os.path.isdir(root) and root not in roots:
            roots.append(root)
    return roots


def find_clusters():
    found = []
    for root in klei_roots():
        try:
            user_ids = os.listdir(root)
        except OSError:
            continue
        for uid in user_ids:
            udir = os.path.join(root, uid)
            if not (uid.isdigit() and os.path.isdir(udir)):
                continue
            try:
                names = os.listdir(udir)
            except OSError:
                continue
            for name in names:
                cdir = os.path.join(udir, name)
                if name.startswith("Cluster_") and os.path.isdir(os.path.join(cdir, "Master")):
                    found.append(cdir)

    def mtime(path):
        try:
            return os.path.getmtime(os.path.join(path, "Master"))
        except OSError:
            return 0

    found.sort(key=mtime, reverse=True)  # самые свежие миры сверху
    return found


def cluster_title(cdir):
    name = ""
    try:
        cp = configparser.ConfigParser(interpolation=None)
        cp.read(os.path.join(cdir, "cluster.ini"), encoding="utf-8")
        name = cp.get("NETWORK", "cluster_name", fallback="")
    except Exception:
        pass
    base = os.path.basename(cdir)
    return f"{base} — {name}" if name else base


# ------------------------------------------------------------------ окно
class App:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry("780x800")
        root.minsize(700, 700)

        self.events = queue.Queue()
        self.bridge = None
        self.settings = load_settings()
        self.clusters = {}       # заголовок -> папка кластера
        self.texts = []          # (виджет, опция, ключ перевода, в рамке с пробелами)
        self.log_entries = []    # (время, ключ, параметры): журнал хранится ключами
        self.status_info = ("stopped", "status_stopped", {})

        lang = self.settings.get("language")
        set_language(lang if lang in LANGUAGES else detect_language())

        self.language_var = tk.StringVar(value=LANGUAGES[get_language()])
        self.cluster_var = tk.StringVar()
        self.also_caves = tk.BooleanVar(value=bool(self.settings["also_caves"]))
        self.channel_var = tk.StringVar(value=self.settings["channel"])
        self.bot_var = tk.StringVar(value=self.settings["bot_username"])
        self.token_var = tk.StringVar(value=self.settings["oauth_token"])
        self.show_token = tk.BooleanVar(value=False)
        self.ignore_var = tk.StringVar(value=self.settings["ignore_users"])
        self.ignore_cmd = tk.BooleanVar(value=bool(self.settings["ignore_commands"]))
        self.max_len = tk.IntVar(value=int(self.settings["max_len"]))

        self.build_ui()
        self.apply_language()
        self.refresh_clusters()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.pump)
        self.log("log_ready")

    # -------------------------------------------------------------- интерфейс
    def bind(self, widget, key, option="text", framed=False):
        """Запоминает, какой ключ перевода относится к виджету (для смены языка)."""
        self.texts.append((widget, option, key, framed))
        return widget

    def build_ui(self):
        pad = {"padx": 10, "pady": 5}
        main = ttk.Frame(self.root, padding=8)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)

        # Язык
        bar = ttk.Frame(main)
        bar.grid(row=0, column=0, sticky="e", padx=10, pady=(0, 2))
        self.bind(ttk.Label(bar), "lang_label").pack(side="left", padx=(0, 6))
        lang_box = ttk.Combobox(bar, textvariable=self.language_var, state="readonly",
                                values=list(LANGUAGES.values()), width=20)
        lang_box.pack(side="left")
        lang_box.bind("<<ComboboxSelected>>", self.on_language)

        # 1. Игра
        game = self.bind(ttk.LabelFrame(main), "sec_world", framed=True)
        game.grid(row=1, column=0, sticky="ew", **pad)
        game.columnconfigure(0, weight=1)
        self.cluster_box = ttk.Combobox(game, textvariable=self.cluster_var, state="readonly")
        self.cluster_box.grid(row=0, column=0, sticky="ew", padx=8, pady=6)
        self.bind(ttk.Button(game, command=self.refresh_clusters), "btn_refresh").grid(
            row=0, column=1, padx=2)
        self.bind(ttk.Button(game, command=self.browse), "btn_browse").grid(
            row=0, column=2, padx=(2, 8))
        self.bind(ttk.Label(game, foreground="#616161", wraplength=700, justify="left"),
                  "world_hint").grid(row=1, column=0, columnspan=3, sticky="w", padx=8)
        self.bind(ttk.Checkbutton(game, variable=self.also_caves), "also_caves").grid(
            row=2, column=0, columnspan=3, sticky="w", padx=8, pady=(2, 6))

        # 2. Twitch
        tw = self.bind(ttk.LabelFrame(main), "sec_twitch", framed=True)
        tw.grid(row=2, column=0, sticky="ew", **pad)
        tw.columnconfigure(1, weight=1)
        self.bind(ttk.Label(tw), "lbl_channel").grid(row=0, column=0, sticky="w", padx=8, pady=4)
        ttk.Entry(tw, textvariable=self.channel_var).grid(
            row=0, column=1, columnspan=2, sticky="ew", padx=8)
        self.bind(ttk.Label(tw), "lbl_bot").grid(row=1, column=0, sticky="w", padx=8, pady=4)
        ttk.Entry(tw, textvariable=self.bot_var).grid(
            row=1, column=1, columnspan=2, sticky="ew", padx=8)
        self.bind(ttk.Label(tw), "lbl_token").grid(row=2, column=0, sticky="w", padx=8, pady=4)
        self.token_entry = ttk.Entry(tw, textvariable=self.token_var, show="•")
        self.token_entry.grid(row=2, column=1, sticky="ew", padx=8)
        self.bind(ttk.Checkbutton(tw, variable=self.show_token, command=self.toggle_token),
                  "chk_show").grid(row=2, column=2, padx=(0, 8))
        self.bind(ttk.Button(tw, command=lambda: webbrowser.open(TOKEN_URL)),
                  "btn_token_help").grid(row=3, column=1, sticky="w", padx=8, pady=2)
        self.bind(ttk.Label(tw, foreground="#616161", wraplength=700, justify="left"),
                  "token_hint").grid(row=4, column=0, columnspan=3, sticky="w", padx=8, pady=(2, 6))

        # 3. Фильтры
        flt = self.bind(ttk.LabelFrame(main), "sec_filters", framed=True)
        flt.grid(row=3, column=0, sticky="ew", **pad)
        flt.columnconfigure(1, weight=1)
        self.bind(ttk.Label(flt), "lbl_ignore").grid(row=0, column=0, sticky="w", padx=8, pady=4)
        ttk.Entry(flt, textvariable=self.ignore_var).grid(
            row=0, column=1, columnspan=2, sticky="ew", padx=8)
        self.bind(ttk.Checkbutton(flt, variable=self.ignore_cmd), "chk_ignore_cmd").grid(
            row=1, column=0, columnspan=3, sticky="w", padx=8)
        self.bind(ttk.Label(flt), "lbl_maxlen").grid(row=2, column=0, sticky="w", padx=8, pady=4)
        ttk.Spinbox(flt, from_=40, to=300, width=6, textvariable=self.max_len).grid(
            row=2, column=1, sticky="w", padx=8)

        # Управление
        ctrl = ttk.Frame(main)
        ctrl.grid(row=4, column=0, sticky="ew", **pad)
        self.start_btn = ttk.Button(ctrl, command=self.toggle)
        self.start_btn.pack(side="left")
        self.test_btn = self.bind(ttk.Button(ctrl, command=self.test, state="disabled"), "btn_test")
        self.test_btn.pack(side="left", padx=8)
        self.status_label = tk.Label(ctrl, anchor="w")
        self.status_label.pack(side="left", padx=10)

        # Журнал
        self.log_box = scrolledtext.ScrolledText(main, height=10, state="disabled", wrap="word")
        self.log_box.grid(row=5, column=0, sticky="nsew", **pad)
        main.rowconfigure(5, weight=1)

        # Поддержка
        sup = self.bind(ttk.LabelFrame(main), "sec_support", framed=True)
        sup.grid(row=6, column=0, sticky="ew", **pad)
        for i, (title, url) in enumerate(SUPPORT_LINKS):
            ttk.Button(sup, text=title, command=lambda u=url: webbrowser.open(u)).grid(
                row=0, column=i, padx=6, pady=6)

    def apply_language(self):
        """Выставляет тексты всех виджетов, статуса и журнала на выбранном языке."""
        for widget, option, key, framed in self.texts:
            text = tx(key)
            widget.configure(**{option: f" {text} " if framed else text})
        self.refresh_buttons()
        self.render_status()
        self.render_log()

    def on_language(self, _event=None):
        set_language(language_from_name(self.language_var.get()))
        self.apply_language()
        self.save()

    def refresh_buttons(self):
        running = self.bridge is not None
        self.start_btn.configure(text=tx("btn_stop" if running else "btn_start"))
        self.test_btn.configure(state="normal" if running else "disabled")

    def toggle_token(self):
        self.token_entry.configure(show="" if self.show_token.get() else "•")

    # ---------------------------------------------------------------- миры
    def refresh_clusters(self):
        self.clusters = {}
        saved = self.settings.get("cluster_dir") or ""
        dirs = find_clusters()
        if saved and os.path.isdir(saved) and saved not in dirs:
            dirs.append(saved)
        for cdir in dirs:
            self.add_cluster(cdir)

        current = ""
        for title, cdir in self.clusters.items():
            if cdir == saved:
                current = title
        if not current and self.clusters:
            current = next(iter(self.clusters))
        self.cluster_box["values"] = list(self.clusters)
        self.cluster_var.set(current)
        if not self.clusters:
            self.log("log_no_worlds")

    def add_cluster(self, cdir):
        title = cluster_title(cdir)
        if title in self.clusters and self.clusters[title] != cdir:
            title += f" [{os.path.basename(os.path.dirname(cdir))}]"
        self.clusters[title] = cdir
        return title

    def browse(self):
        d = filedialog.askdirectory(title=tx("browse_title"))
        if not d:
            return
        d = os.path.normpath(d)
        if not os.path.isdir(os.path.join(d, "Master")):
            messagebox.showwarning(APP_TITLE, tx("browse_bad"))
            return
        title = self.add_cluster(d)
        self.cluster_box["values"] = list(self.clusters)
        self.cluster_var.set(title)

    # ------------------------------------------------------------ настройки
    def collect(self):
        cdir = self.clusters.get(self.cluster_var.get(), "")
        master = os.path.join(cdir, "Master", "save") if cdir else ""
        caves = os.path.join(cdir, "Caves", "save") if cdir and self.also_caves.get() else ""
        try:
            max_len = int(self.max_len.get())
        except (tk.TclError, ValueError):
            max_len = 140
        return {
            "language": get_language(),
            "channel": self.channel_var.get().strip(),
            "bot_username": self.bot_var.get().strip(),
            "oauth_token": self.token_var.get().strip(),
            "cluster_dir": cdir,
            "also_caves": bool(self.also_caves.get()),
            "ignore_users": self.ignore_var.get(),
            "ignore_commands": bool(self.ignore_cmd.get()),
            "max_len": max_len,
            "master_save_dir": master,
            "caves_save_dir": caves,
        }

    def save(self):
        data = self.collect()
        for key in ("master_save_dir", "caves_save_dir"):
            data.pop(key, None)
        save_settings(data)

    # ------------------------------------------------------------- запуск
    def toggle(self):
        if self.bridge is not None:
            self.stop()
            return

        s = self.collect()
        if s["oauth_token"] and not s["bot_username"]:
            messagebox.showwarning(APP_TITLE, tx("warn_token_no_bot"))
            return

        bridge_settings = dict(s)
        bridge_settings["ignore_users"] = [u for u in s["ignore_users"].split(",")]
        bridge = Bridge(bridge_settings, self.log, self.on_status, tr=tx)
        try:
            bridge.start()
        except BridgeError as e:
            messagebox.showerror(APP_TITLE, tx(e.key, **e.kw))
            return

        self.bridge = bridge
        self.save()
        self.refresh_buttons()

    def stop(self):
        if self.bridge is not None:
            self.bridge.stop()
            self.bridge = None
        self.refresh_buttons()

    def test(self):
        if self.bridge is not None:
            self.bridge.send_test()

    # ------------------------------------------------- события из потоков
    def log(self, key, **params):
        self.events.put(("log", (time.strftime("[%H:%M:%S] "), key, params)))

    def on_status(self, state, key, **params):
        self.events.put(("status", (state, key, params)))

    def pump(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "log":
                    self.append_log(payload)
                elif kind == "status":
                    self.status_info = payload
                    self.render_status()
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def render_status(self):
        state, key, params = self.status_info
        self.status_label.configure(text=tx(key, **params),
                                    fg=STATUS_COLORS.get(state, "#616161"))

    def append_log(self, entry):
        self.log_entries.append(entry)
        if len(self.log_entries) > 1000:
            del self.log_entries[:200]
            self.render_log()
            return
        box = self.log_box
        box.configure(state="normal")
        box.insert("end", self.format_entry(entry) + "\n")
        box.see("end")
        box.configure(state="disabled")

    def render_log(self):
        box = self.log_box
        box.configure(state="normal")
        box.delete("1.0", "end")
        for entry in self.log_entries:
            box.insert("end", self.format_entry(entry) + "\n")
        box.see("end")
        box.configure(state="disabled")

    @staticmethod
    def format_entry(entry):
        stamp, key, params = entry
        return stamp + tx(key, **params)

    def on_close(self):
        self.save()
        self.stop()
        self.root.destroy()


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
