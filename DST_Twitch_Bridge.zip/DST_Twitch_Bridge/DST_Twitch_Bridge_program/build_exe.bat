@echo off
rem Builds DST_Twitch_Bridge.exe (requires Python 3 installed)
cd /d "%~dp0"
py -3 -m pip install --upgrade pyinstaller
py -3 -m PyInstaller --noconfirm --onefile --windowed --name "DST_Twitch_Bridge" dst_twitch_bridge.py
echo.
echo Done: dist\DST_Twitch_Bridge.exe
pause
