@echo off
rem Run the program without building an exe (needs Python 3 with tkinter)
cd /d "%~dp0"
where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw -3 dst_twitch_bridge.py
) else (
    start "" pythonw dst_twitch_bridge.py
)
