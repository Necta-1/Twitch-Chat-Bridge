DST Twitch Bridge: Twitch chat <-> Don't Starve Together chat
============================================================

Package Contents
----------------
twitch_chat_bridge_mod\            game mod (modinfo.lua, modmain.lua)
DST_Twitch_Bridge_program\         application with settings window
    dst_twitch_bridge.py           application window
    bridge_core.py                 bridge core (communicates with Twitch and the mod via files)
    i18n.py                        interface translations (11 languages)
    run.bat                        launch without building .exe (requires Python 3)
    build_exe.bat                  build DST_Twitch_Bridge.exe as a single file
workshop_description.txt           ready-to-use description for the mod's Workshop page


FOR PLAYERS (How to Use)
------------------------------
1. Enable the Twitch Chat Bridge mod in your world (Mods tab).
   Start the world at least once so the game creates save folders.
2. Launch the DST Twitch Bridge application (.exe or run.bat).
3. Select your world (the program searches for worlds automatically, including in OneDrive),
   enter your Twitch channel name, and click "Start".
   The status "Connected ... (read-only)" means Twitch chat is being sent into the game.
4. To send messages from the game to Twitch, a bot is required:
   - create a separate account for the bot and verify its email;
   - the "How to get token" button will open the token generator website. Log into it using
     the bot's account specifically (easier in an incognito window) and copy the Access token;
   - enter the bot's username and token into the program, click "Start";
   - in your Twitch chat, give the bot moderator status: /mod bot_username.
5. The "Test to game" button sends a test message into the game: this verifies that the mod and
   program can see each other.

Interface Language
- Can be selected in the upper right corner of the window and changes immediately without restarting. Available: English,
  Russian, Ukrainian, Simplified Chinese, Japanese, Korean, Spanish, Portuguese (Brazil), German, French, Polish.
- On first launch, the system language is used; subsequent launches remember the chosen one.
- The window, log, status, and error messages are translated. The mod itself and its description are not translated.

Important
- The program must run on the same computer where the world files are located
  (i.e., the host's computer). Server players do not need to install anything.
- The bot token is stored in plaintext on your computer at:
  %APPDATA%\DST_Twitch_Bridge\settings.json. Do not show or send it to anyone. If the token
  accidentally appears in a screenshot or chat, disable the token generator application in
  your Twitch settings (Settings -> Connections) and get a new one.
- If in-game messages do not reach Twitch, check the log in the program window:
  it will display the Twitch response (e.g., "verifying email or phone number needed").
- If Twitch messages are not visible in caves, check the box "Also send messages
  to caves" and enable the mod in the cave shard as well.


FOR THE AUTHOR (Building and Publishing)
----------------------------------------
Building .exe
  1. Install Python 3 from python.org (check "Add to PATH" and the tcl/tk component).
  2. Run build_exe.bat. The finished file will appear in the dist folder.
  Antivirus software sometimes flags .exe files built with PyInstaller. If this happens, distribute
  the program as an archive containing .py and run.bat instead.

Where to Host the Program
  Any platform offering a direct link, such as GitHub Releases or cloud storage.
  Replace DOWNLOAD_LINK in workshop_description.txt with this link.

Publishing the Mod to the Workshop
  1. Copy the twitch_chat_bridge_mod folder into the game's mods folder
     (Steam\steamapps\common\Don't Starve Together\mods).
  2. In Steam, open Library, switch the filter from "Games" to "Tools", and
     launch Don't Starve Mod Tools. Select uploading to the Don't Starve Together workshop
     and choose your mod folder.
  3. Fill in the title, image, and description in the uploader screen, using the text
     from workshop_description.txt for the description (formatted with Steam BBCode).
  See Klei's guides for details and restrictions regarding icons and images.

Support Links
  YouTube, Donatello, and Ko-fi are defined in the SUPPORT_LINKS list at the beginning of dst_twitch_bridge.py. To add Patreon, append the following line to the list:
  ("Patreon", "https://www.patreon.com/your_page"). Add the same address to the
  "Support the Author" block in workshop_description.txt.

How to Add a Language
  Open i18n.py, add the code and name to the LANGUAGES dictionary, copy the "en" block in STRINGS
  under the new code, and translate the values. Placeholders in curly braces ({channel}, {err}, etc.)
  must not be changed. Missing strings automatically fall back to English.